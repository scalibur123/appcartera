#!/usr/bin/env python3
"""
update_from_excel_v2.py

Lee el Excel de Mario y regenera:
  1. index.html con la const C actualizada
  2. tickers.json con el mapa ticker_excel -> simbolo_yahoo resuelto

Reglas de resolucion del simbolo Yahoo:
  1. Si esta en tickers_override.json -> usar ese (PRIORIDAD MAXIMA)
  2. Si moneda == USD -> usar ticker tal cual (con sufijos US si aplica)
  3. Si moneda == EUR sin sufijo -> tabla SFX por patron
  4. Si ya tiene sufijo (PAH3.DE, etc) -> usar tal cual
"""

import openpyxl
import json
import os
import re
import sys
from pathlib import Path
from datetime import datetime

# === Configuracion ===
HOME = Path.home()
PROYECTO = HOME / "APPCARTERA_NUEVA"
EXCEL = HOME / "AppCartera_Data" / "PLUSVALIAS BOLSA 26_APP.xlsm"
HOJA = "2026"
FILA_INI = 5
FILA_FIN = 258  # cartera viva, antes de EJECUCIONES
INDEX_HTML = PROYECTO / "index.html"
TICKERS_JSON = PROYECTO / "tickers.json"
OVERRIDE_JSON = PROYECTO / "tickers_override.json"

# === Tabla SFX por defecto para tickers EUR sin sufijo ===
# Asumimos Madrid (.MC) como bolsa por defecto para ES
# Solo se usa si el ticker NO esta en tickers_override.json
SFX_DEFAULT_EUR = ".MC"

# Mapeo de tickers conocidos por bolsa cuando no hay override
SFX_POR_PATRON = {
    # Si terminan en patron tipico aleman (numero)
    r"^[A-Z]+[0-9]$": ".DE",
    # Default: Madrid
}


def cargar_overrides():
    """Carga tickers_override.json si existe"""
    if OVERRIDE_JSON.exists():
        with open(OVERRIDE_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Filtrar claves que empiezan por _ (comentarios)
        return {k: v for k, v in data.items() if not k.startswith("_")}
    print(f"⚠️  No existe {OVERRIDE_JSON}. Se usara solo auto-resolucion.")
    return {}


def resolver_simbolo_yahoo(ticker, moneda, overrides):
    """Resuelve el simbolo Yahoo para un ticker dado."""
    # 1. Override manual gana siempre
    if ticker in overrides:
        return overrides[ticker], "override"

    # 2. Si ya tiene punto, asumimos que ya es Yahoo-format
    if "." in ticker or "=" in ticker:
        return ticker, "ya_tenia_sufijo"

    # 3. USD: usar tal cual (Nasdaq/NYSE no llevan sufijo en Yahoo)
    if moneda == "USD":
        return ticker, "usd_directo"

    # 4. EUR sin sufijo: aplicar patron por defecto (Madrid)
    if moneda == "EUR":
        for patron, sfx in SFX_POR_PATRON.items():
            if re.match(patron, ticker):
                return ticker + sfx, f"patron_{sfx}"
        return ticker + SFX_DEFAULT_EUR, "default_madrid"

    # 5. Otra moneda: dejarlo y avisar
    return ticker, "moneda_desconocida"


def leer_excel():
    """Lee el Excel y devuelve lista de posiciones agregadas por ticker."""
    if not EXCEL.exists():
        print(f"❌ No encuentro el Excel en {EXCEL}")
        sys.exit(1)

    wb = openpyxl.load_workbook(EXCEL, data_only=True, keep_vba=False)
    ws = wb[HOJA]

    posiciones = {}
    for row in range(FILA_INI, FILA_FIN + 1):
        ticker = ws[f"D{row}"].value
        if not ticker or not str(ticker).strip():
            continue
        ticker = str(ticker).strip()
        titulos = ws[f"K{row}"].value or 0
        coste_eur = ws[f"N{row}"].value or 0
        moneda = ws[f"G{row}"].value
        precio_excel = ws[f"E{row}"].value
        nombre = ws[f"B{row}"].value

        if ticker not in posiciones:
            posiciones[ticker] = {
                "ticker": ticker,
                "nombre": nombre if not isinstance(nombre, str) or "#" not in nombre else "",
                "titulos": 0,
                "coste_eur": 0,
                "moneda": moneda,
                "precio_excel": precio_excel,
                "filas": [],
            }
        posiciones[ticker]["titulos"] += titulos
        posiciones[ticker]["coste_eur"] += coste_eur
        posiciones[ticker]["filas"].append(row)

    return list(posiciones.values())


def construir_const_C(posiciones, ticker_map):
    """Genera el JS de const C = [...] con simbolo Yahoo correcto."""
    items = []
    for p in posiciones:
        sym = ticker_map[p["ticker"]]["yahoo"]
        items.append(
            "  {"
            f'symbol:"{sym}",'
            f'ticker:"{p["ticker"]}",'
            f'titulos:{p["titulos"]},'
            f'coste:{p["coste_eur"]:.4f},'
            f'moneda:"{p["moneda"]}"'
            "}"
        )
    return "const C = [\n" + ",\n".join(items) + "\n];"


def actualizar_index_html(const_C_js):
    """Reemplaza el bloque const C = [...] en index.html"""
    if not INDEX_HTML.exists():
        print(f"❌ No encuentro {INDEX_HTML}")
        sys.exit(1)

    html = INDEX_HTML.read_text(encoding="utf-8")

    # Buscar el bloque "const C = [" hasta el "];" mas cercano
    pattern = re.compile(r"const\s+C\s*=\s*\[[\s\S]*?\n\s*\];", re.MULTILINE)
    if not pattern.search(html):
        print("❌ No se encontro el bloque 'const C = [...]' en index.html")
        sys.exit(1)

    nuevo_html = pattern.sub(const_C_js, html, count=1)
    # Backup antes de escribir
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = INDEX_HTML.parent / f"index.html.backup_{timestamp}"
    backup.write_text(html, encoding="utf-8")
    INDEX_HTML.write_text(nuevo_html, encoding="utf-8")
    print(f"✅ index.html actualizado. Backup en {backup.name}")


def main():
    print(f"📂 Leyendo Excel: {EXCEL}")
    posiciones = leer_excel()
    print(f"✅ {len(posiciones)} tickers unicos cargados (filas {FILA_INI}-{FILA_FIN})")

    overrides = cargar_overrides()
    print(f"✅ {len(overrides)} overrides manuales cargados")

    # Resolver simbolo Yahoo para cada ticker
    ticker_map = {}
    stats = {"override": 0, "ya_tenia_sufijo": 0, "usd_directo": 0, "default_madrid": 0, "moneda_desconocida": 0}
    for p in posiciones:
        sym, fuente = resolver_simbolo_yahoo(p["ticker"], p["moneda"], overrides)
        ticker_map[p["ticker"]] = {
            "yahoo": sym,
            "moneda": p["moneda"],
            "titulos": p["titulos"],
            "coste_eur": round(p["coste_eur"], 4),
            "precio_excel": p["precio_excel"] if isinstance(p["precio_excel"], (int, float)) else None,
            "fuente_resolucion": fuente,
        }
        stats[fuente] = stats.get(fuente, 0) + 1

    print(f"\n📊 Resolucion de simbolos:")
    for fuente, n in sorted(stats.items(), key=lambda x: -x[1]):
        print(f"   {fuente}: {n}")

    # Guardar tickers.json
    with open(TICKERS_JSON, "w", encoding="utf-8") as f:
        json.dump(ticker_map, f, indent=2, ensure_ascii=False)
    print(f"\n✅ Guardado {TICKERS_JSON}")

    # Generar const C y actualizar index.html
    const_C_js = construir_const_C(posiciones, ticker_map)
    actualizar_index_html(const_C_js)

    print("\n🎯 Listo. Siguiente paso:")
    print("   python3 validate.py")
    print("   (te dira si Yahoo devuelve precios coherentes con el Excel)")


if __name__ == "__main__":
    main()
